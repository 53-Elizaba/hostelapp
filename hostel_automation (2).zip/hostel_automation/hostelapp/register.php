<?php

include 'config.php';

$rname=$_POST["rname"];
$email=$_POST["email"];
$phone=$_POST["phone"];
$password=$_POST["password"];
$query="insert into registration(rname,email,phone,password) values ('$rname','$email','$phone','$password')";
$result=mysqli_query($con,$query) or die (mysqli_error($con));
if($result)
{
        $response["status"]="1";
        $response["message"]="Registration Successful";
}
else
{
        $response["status"]="0";
        $response["message"]="Registration Failed";
}
echo json_encode($response);
?>