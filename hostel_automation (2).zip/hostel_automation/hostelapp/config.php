<?php
$con=mysqli_connect('localhost','root','elizaba');
$db=mysqli_select_db($con,'hostel_db');
?>