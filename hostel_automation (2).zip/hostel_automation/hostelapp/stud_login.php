<?php

include 'config.php';

$stud_username=$_POST["stud_username"];
$stud_password=$_POST["stud_password"];
$query="Select * from student_reg where stud_username='$stud_username' && stud_password='$stud_password' ";
$result=mysqli_query($con,$query);
$row=mysqli_fetch_row($result);
if(mysqli_num_rows($result)>0)
{
    $response["status"]="1";
    $response["message"]="Login Successful";
}
else
{
    $response["status"]="0";
    $response["message"]="Login Failed";
}
echo json_encode($response);
?>