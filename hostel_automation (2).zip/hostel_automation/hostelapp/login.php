<?php

include 'config.php';

$rname=$_POST["rname"];
$password=$_POST["password"];
$query="Select * from registration where rname='$rname' && password='$password' ";
$result=mysqli_query($con,$query);
$row=mysqli_fetch_row($result);
if(mysqli_num_rows($result)>0)
{
    $response["status"]="1";
    $response["message"]="Login Successful";
}
else
{
    $response["status"]="0";
    $response["message"]="Login Failed";
}
echo json_encode($response);
?>